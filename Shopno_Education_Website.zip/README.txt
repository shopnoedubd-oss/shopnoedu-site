SHOPNO EDUCATION - WEBSITE (www.shopnoedu.com)
================================================
HOW TO PUBLISH ON HOSTINGER
1. Log in to hPanel -> Websites -> shopnoedu.com -> File Manager.
2. Open the "public_html" folder. Delete the default file (default.php / index.php) if present.
3. Upload everything from this folder (index.html, robots.txt, sitemap.xml and the "assets" folder)
   directly into public_html - or upload the ZIP and use "Extract".
4. Visit https://www.shopnoedu.com - done. In hPanel -> SSL, make sure the free SSL is active.

WHAT TO EDIT (open index.html in any text editor)
- Phone / WhatsApp: search for 8801817161889 and +880 1817-161889
- Email: search for shopnoedu.bd@gmail.com
- Office address: add a new "info" card in the Contact section
- CEO message: search for id="ceo"
- Partner names / logos: search for "TIP: add your real partner logos"
- Photos: replace assets/ceo.jpg (keep a 4:5 portrait) and assets/icon.png (logo icon)

FILES
index.html  - the whole website (HTML + CSS + JS, mobile friendly, light/dark aware)
assets/     - icon.png (logo), ceo.jpg, favicon.png, og-image.png (social sharing image)
robots.txt, sitemap.xml - for Google
